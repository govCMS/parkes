Pancake
=======

> Pancake is a tool to make working with npm on the front end easy and sweet.


## Versions

* [v1.0.5 - 💥 Initial version](v105)


----------------------------------------------------------------------------------------------------------------------------------------------------------------


## v1.0.6

- Fixed some bugs


## v1.0.5

- 💥 Initial version


**[⬆ back to top](#contents)**


# };
